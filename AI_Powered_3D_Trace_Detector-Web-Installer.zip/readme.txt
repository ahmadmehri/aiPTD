To install the application, launch the program file AI_Powered_3D_Trace_Detector.exe

If the installation does not start, it is advised to deactivate the Windows Security and try again to ensure a smooth installation process.

An internet connection is needed to download and install MATLAB Runtime R2023b.

It's recommended that the 3D model be used in the '00-Sample Data' folder to test the software after installation.

This is free software only for research.


Note:
THE SOFTWARE IS PROVIDED "AS IS" AND WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. LICENSOR DISCLAIMS ALL WARRANTIES, INCLUDING ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT. THE LICENSOR DOES NOT WARRANT THAT THE SOFTWARE WILL BE ERROR-FREE OR WILL FUNCTION WITHOUT INTERRUPTION.


